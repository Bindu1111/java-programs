/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package recipes.presenter;

import static java.lang.Integer.parseInt;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;
import recipes.model.IQueries;
import recipes.model.Recipe;
import recipes.view.IView;

/**
 *
 * @author shaik sohail
 */
public class RecipePresenter {
    IView view;
    IQueries queries;
    List<Recipe> result;
    Recipe currentEntry;
    int currentEntryIndex;
    int numberOfEntries;

    public RecipePresenter(IView iv, IQueries iq) {
       view=iv;
       queries = iq;
       currentEntryIndex = 0;
       numberOfEntries = 0;
       currentEntry = null;
    }



    private void populateText(){
             
        view.setOutput("recipe Name:"+currentEntry.getName());
                   
    }
    public void category()
    {
        try{
        
        result = queries.getByRecipeName( view.getCategory());
            numberOfEntries = result.size();
            if ( numberOfEntries != 0 ) {
                currentEntryIndex = 0;
                currentEntry = result.get( currentEntryIndex );
                view.setOutput(currentEntry.getName()); 
                
            } 
        }
        
        catch(SQLException e)
        {
            e.printStackTrace();
            System.exit( 1 );
        }
    }


    
    public void insertNewEntry(){
        try{
            
            int result = queries.addRecipes(
                    view.getRecipeName(),
                    view.getCategory(),
                     view.getIngredient(),
                    view.getPreparation(),
                    view.getCooking()
                   
            );
           if ( result == 1 )
                view.showMessageDialog("Recipe added!", "Recipe added");
            else
                view.showMessageDialog("Recipe not added!", "Error");  
        }
        catch(SQLException e)
        {
            e.printStackTrace();
            System.exit( 1 );
        }
    }
    
    public void CategoryPreparation()
    {
        try{
        
        result = queries.getCategoryPreparation(view.getCategory());
            numberOfEntries = result.size();
            if ( numberOfEntries != 0 ) {
                currentEntryIndex = 0;
                currentEntry = result.get( currentEntryIndex );
                view.setOutput("Recipe Name:"+currentEntry.getName());
                 
                 
            } 
            
        }
        
        catch(SQLException e)
        {
            e.printStackTrace();
            System.exit( 1 );
        }
        
        
    }
    public void CategoryCombined()
    {
     try{
        
        result = queries.getCategoryCombined(view.getCategory());
            numberOfEntries = result.size();
            if ( numberOfEntries != 0 ) {
                currentEntryIndex = 0;
                currentEntry = result.get( currentEntryIndex );
                String preparation=currentEntry.getRecipePreparationTime();
                int p=parseInt(preparation);
                String cooking=currentEntry.getRecipeCookingTime();
                int c=parseInt(cooking);
                int combinedtime=p+c;
                view.setOutput("Recipe Name:"+currentEntry.getName()+"\n"+"Category:"+currentEntry.getRecipeCategory());
                
            } 
        }
        
        catch(SQLException e)
        {
            e.printStackTrace();
            System.exit( 1 );
        }   
    }
    public void Ingredient()
    {
        try{
             result = queries.getIngredient(view.getIngredient());
            numberOfEntries = result.size();
            if ( numberOfEntries != 0 ) {
                currentEntryIndex = 0;
                currentEntry = result.get( currentEntryIndex );
                view.setOutput("Recipe Name:"+currentEntry.getName());
                 
                 
            }    
        }
        catch ( SQLException e ) {
            e.printStackTrace();
            System.exit( 1 );
        }
    }
    
     public void close() {
        try {
            queries.close();
            System.exit(0);
        }
        catch ( SQLException e ) {
            e.printStackTrace();
            System.exit( 1 );
        }
    }
     public void clear()
     {
        Textclear();
     }

    private void Textclear() {
      view.setCategory("");
      view.setRecipeName("");
      view.setCombined("");
      view.setCooking("");
      view.setIngredient("");
      view.setOutput("");
      view.setPreparation("");
      view.setTextfiled3("");
      view.setTextfiled5("");
      view.setTextfiled7("");
    }
}
