/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package recipes;

import java.sql.SQLException;
import recipes.model.RecipeQueries;
import recipes.presenter.RecipePresenter;

import recipes.view.RecipesView;

/**
 *
 * @author shaik sohail
 */
public class Recipes {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        try {
        RecipeQueries rq = new RecipeQueries();
        RecipesView rv=new RecipesView();
        RecipePresenter rp= new RecipePresenter( rv, rq );
        rv.bind(rp);
        }
        catch(SQLException e)
        {
           e.printStackTrace();
           System.exit( 1 );
        }
    
    }
    
}
