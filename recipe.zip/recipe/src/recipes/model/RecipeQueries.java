/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package recipes.model;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author shaik sohail
 */
public class RecipeQueries implements IQueries {
    private static final String URL = "jdbc:mysql://localhost:3306/recipes";
    private static final String USERNAME = "root";
    private static final String PASSWORD = "";
    
    private Connection connection = null; // manages connection
    private PreparedStatement selectAllRecipe = null; 
    private PreparedStatement selectByRecipeName = null; 
    private PreparedStatement insertNewRecipe = null;
    private PreparedStatement selectCategoryPreparation=null;
    private PreparedStatement selectCategoryCombined=null;
    private PreparedStatement selectIngredient=null;
    
     public RecipeQueries() throws SQLException {
        connection = DriverManager.getConnection( URL, USERNAME, PASSWORD );
        
        selectAllRecipe = connection.prepareStatement( "SELECT * FROM recipe" ); 
        
        selectByRecipeName = connection.prepareStatement( "SELECT * FROM recipe WHERE category = ?" );
        
        selectCategoryPreparation = connection.prepareStatement ("SELECT * FROM recipe WHERE category=?");
        
        selectCategoryCombined = connection.prepareStatement("SELECT * FROM recipe WHERE category=?");
        
        selectIngredient = connection.prepareStatement("SELECT * FROM recipe WHERE mainingredient=?");
        
        insertNewRecipe = connection.prepareStatement( "INSERT INTO recipe ( recipename, category,mainingredient, preparationtime, cookingtime ) VALUES ( ?, ?, ?, ?,? )" );

     }
     
        private Recipe createRecipes( ResultSet rs ) throws SQLException {
        return new Recipe(
            rs.getInt("id"),
            rs.getString( "recipename" ),
            rs.getString( "category" ),
            rs.getString( "mainingredient" ),
            rs.getString ("preparationtime" ) ,
            rs.getString( "cookingtime" ) 
        );
    }
        private Recipe CatandPre(ResultSet rs)throws SQLException {
        return new Recipe(
         
            rs.getString( "category" ),
            rs.getString ("preparationtime" ) 
           
        );
        }
                private Recipe createRecipe(ResultSet rs)throws SQLException {
        return new Recipe(
         
            rs.getString( "recipename" )
             
           
        );
    }

           @Override
    public List< Recipe > getAllRecipe() throws SQLException {
  
        try( ResultSet resultSet = selectAllRecipe.executeQuery() ) {
            List<Recipe> results = new ArrayList<>();
            while ( resultSet.next() )
                results.add( createRecipes( resultSet ) );
            return results;
        }   
    }
    
        @Override
    public List< Recipe > getByRecipeName( String name ) throws SQLException {
  
        selectByRecipeName.setString( 1, name ); 
       
        try( ResultSet resultSet = selectByRecipeName.executeQuery() ) {
            List<Recipe> results = new ArrayList<>();
            while ( resultSet.next() )
                results.add( createRecipes( resultSet ) );
            return results;
        }  
    }

    @Override
      public List<Recipe> getCategoryPreparation (String name) throws SQLException{
          selectCategoryPreparation.setString(1,name);
          try(ResultSet resultSet = selectCategoryPreparation.executeQuery()){
              List<Recipe> results =new ArrayList<>();
              while(resultSet.next())
                  results.add(createRecipes(resultSet));
              return results;
          }
        
      }
      @Override
    public void close() throws SQLException {
        
    
    try( Connection c = connection ) {
            selectAllRecipe.close(); 
            selectByRecipeName.close(); 
            insertNewRecipe.close();
        }
    
    }

    @Override
    public int addRecipes(String RecipeName, String Category, String MainIngredient, String PreparationTime, String CookingTime) throws SQLException {
        
        
    insertNewRecipe.setString(1, RecipeName);
    insertNewRecipe.setString(2, Category);
    insertNewRecipe.setString(3, MainIngredient);
    insertNewRecipe.setString(4, PreparationTime);
    insertNewRecipe.setString(5, CookingTime);
    
    return  insertNewRecipe.executeUpdate();
    }

    @Override
    public List<Recipe> getCategoryCombined(String name) throws SQLException {
        selectCategoryCombined.setString(1,name);
          try(ResultSet resultSet = selectCategoryCombined.executeQuery()){
              List<Recipe> results =new ArrayList<>();
              while(resultSet.next())
                  results.add(createRecipes(resultSet));
              return results;
          }
    }

    @Override
    public List<Recipe> getIngredient(String name) throws SQLException {
       selectIngredient.setString(1,name);
          try(ResultSet resultSet = selectIngredient.executeQuery()){
              List<Recipe> results =new ArrayList<>();
              while(resultSet.next())
                  results.add(createRecipes(resultSet));
              return results;
          }
    }

    @Override
    public List<Recipe> getCategoryPreparation(String category, String preparation) throws SQLException{
              
          selectCategoryPreparation.setString(1,category);
          selectCategoryPreparation.setString(2,preparation);
          try(ResultSet resultSet = selectCategoryPreparation.executeQuery()){
              List<Recipe> results =new ArrayList<>();
              while(resultSet.next())
                  results.add(createRecipe(resultSet));
              return results;
          }
        
      }
    

}
