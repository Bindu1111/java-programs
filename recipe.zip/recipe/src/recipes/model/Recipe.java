/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package recipes.model;

/**
 *
 * @author shaik sohail
 */
public class Recipe {
    
    private int RecipeId;
    private String Name;
    private String RecipeCategory;
    private String RecipeMainIngredient;
    private String RecipePreparationTime;
    private String RecipeCookingTime;
    
    public Recipe()
    {
        
    }

    public Recipe(int id, String RecipeName, String Category, String MainIngredient, String PreparationTime, String CookingTime) {
        
        setRecipeId( id );
        setName( RecipeName );
        setRecipeCategory( Category );
        setRecipeMainIngredient( MainIngredient );
        setRecipePreparationTime( PreparationTime );
        setRecipeCookingTime( CookingTime );
         
    }

    Recipe(String Category, String PreparationTime) {
        setRecipeCategory( Category );
        setRecipePreparationTime( PreparationTime );
    }

    Recipe(String RecipeName) {
        setName(RecipeName);
    }

    private void setRecipeId(int id) {
        
        RecipeId= id;
    }
    public int getRecipeId()
    {
        return RecipeId;
    }

    private void setName(String RecipeName) {
       Name= RecipeName;
    }
    public String getName()
    {
        return Name;
    }

    private void setRecipeCategory(String Category) {
        
        RecipeCategory= Category;
    }
    public String getRecipeCategory()
    {
        return RecipeCategory;
    }

    private void setRecipeMainIngredient(String MainIngredient) {
       
        RecipeMainIngredient = MainIngredient;
    }
    public String getRecipeMainIngredient()
    {
        return RecipeMainIngredient;
    }

    private void setRecipePreparationTime(String PreparationTime) {
        
        RecipePreparationTime = PreparationTime;
    }

    public String getRecipePreparationTime()
    {
        return RecipePreparationTime;
    }
    private void setRecipeCookingTime(String CookingTime) {
        RecipeCookingTime = CookingTime;
    }
    
    public String getRecipeCookingTime()
    {
        return RecipeCookingTime;
    }
    
}
