/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package recipes.model;

import java.sql.SQLException;
import java.util.List;

/**
 *
 * @author shaik sohail
 */
public interface IQueries {
      List<Recipe> getCategoryPreparation(String name) throws SQLException;
      List<Recipe> getCategoryCombined(String name) throws SQLException;
      List<Recipe> getIngredient(String name) throws SQLException;
      List< Recipe > getAllRecipe()  throws SQLException;
      List< Recipe > getByRecipeName( String name ) throws SQLException;
      int addRecipes(String RecipeName, String Category, String MainIngredient, String PreparationTime, String CookingTime)  throws SQLException;
      void close() throws SQLException;

    public List<Recipe> getCategoryPreparation(String category, String preparation) throws SQLException;
}
