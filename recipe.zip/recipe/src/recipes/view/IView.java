/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package recipes.view;

/**
 *
 * @author shaik sohail
 */
public interface IView {
    
        void setTextfiled3(String s);
    String getTextfiles3(); 
    void setTextfiled5(String s);
    String getTextfiled5();   
    void setTextfiled7(String s);
    String getTextfiled7();
    void setCategory(String s);
    String getCategory();
    void setPreparation(String s);
    String getPreparation();
    void setCooking(String s);
    String getCooking();
    void setCombined(String s);
    String getCombined();
    void setIngredient(String s);
    String getIngredient();
    void setRecipeName(String s);
    String getRecipeName();
    void setOutput(String s);
    String getOutput();
    public void showMessageDialog(String person_added, String person_added0);

    public String getName();
    
}
