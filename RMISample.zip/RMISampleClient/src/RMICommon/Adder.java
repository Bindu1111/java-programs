package RMICommon;

import java.rmi.*;

//The remote interface is of the contract between a rmi server and a rmi client
public interface Adder extends Remote{

    public RMIMessage add(RMIMessage rmim)throws RemoteException;
}

