package RMICommon;

import java.io.*;
import java.util.List;
import java.util.ArrayList;

//The message is of the contract between a rmi server and a rmi client 
//for remote invocation parameters and results
public class RMIMessage implements Serializable {
    
    //A list of pamameters for remote invocation
    private List<Object> parameters=new ArrayList<Object>();
    //A list of results of remocte invocation
    private List<Object> results=new ArrayList<Object>();
    
    public RMIMessage() {

    }

    public Object getParameter(int i) {
        return parameters.get(i);
    }
    
    public void setParameter (int i, Object parameter) {
        parameters.add(i, parameter);
    }
    
    public Object getResult(int i) {
        return results.get(i);
    }

    public void setResult(int i, Object result) {
	results.add(i, result);
    }

}
