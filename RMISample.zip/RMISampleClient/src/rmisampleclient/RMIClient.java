package rmisampleclient;

import java.rmi.*;

import RMICommon.Adder;
import RMICommon.RMIMessage;

public class RMIClient {

    public static void main(String[] args) {
        try{
            
            //The following directory format is for a Windows machine. If you use a different OS, you will need to set the directory accordingly.
            //Place the security policy in the current working directory
            System.setProperty("java.security.policy","file:\\"+System.getProperty("user.dir")+"\\client.policy");
            //Set security manager for the rmi application.
            System.setSecurityManager(new SecurityManager());
            //Set the parameters for remote invocation
            RMIMessage rmim=new RMIMessage();
            rmim.setParameter(0, new Integer(80));
            rmim.setParameter(1, new Integer(120));
            //Replace the hostname with the domain name of a remote machine where rmi registry is running
            Adder stub=(Adder)Naming.lookup("rmi://CQUROKT27889.staff.ad.cqu.edu.au:5000/sonoo");
            //Output the result of remote invocation
            System.out.println((String)(stub.add(rmim).getResult(0)));
        }catch(Exception e){System.out.println(e);}
    }
}
    

