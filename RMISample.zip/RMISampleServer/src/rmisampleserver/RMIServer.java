package rmisampleserver;

import java.rmi.*;
import java.rmi.registry.*;

import RMICommon.Adder;

/*When only standard Java objects as parameters and results are transferred between a rmi server and a rmi client,
the web servers in the standard RMI framework can be omitted. This example shows a generic way to use any type and 
number of Java standard objects as parameters and results for remote invocation. */
public class RMIServer {

    public static void main(String[] args) {
    
    //The following JVM parameters may help debugging
    //-Djava.rmi.server.logCalls=true
    //-Dsun.rmi.server.logLevel=VERBOSE
    //-Dsun.rmi.client.logCalls=true
    //-Dsun.rmi.transport.tcp.logLevel=VERBOSE

        try{
            
            //Replace the hostname with the domain name of a remote machine where rmi registry is running
            System.setProperty("java.rmi.server.hostname", "CQUROKT27889.staff.ad.cqu.edu.au");
            //The following directory format is for a Windows machine. If you use a different OS, you will need to set the directory accordingly.
            //Place the security policy in the current working directory
            System.setProperty("java.security.policy","file:\\"+System.getProperty("user.dir")+"\\server.policy");
            //Set security manager for the rmi application.
            System.setSecurityManager(new SecurityManager());
            //The rmi registry uses the port 5000
            Registry registry = LocateRegistry.createRegistry(5000);

            Adder stub=new AdderRemote();
            //Replace the hostname with the domain name of a remote machine where rmi registry is running
            Naming.rebind("rmi://CQUROKT27889.staff.ad.cqu.edu.au:5000/sonoo",stub);

        } catch(Exception e) {
            System.out.println(e);
        }
    }
}
