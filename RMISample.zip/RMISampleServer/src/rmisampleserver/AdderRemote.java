
package rmisampleserver;

import java.rmi.*;
import java.rmi.server.*;

import RMICommon.Adder;
import RMICommon.RMIMessage;

//The remote object that can be invoked by a remote client
public class AdderRemote extends UnicastRemoteObject implements Adder{

    AdderRemote()throws RemoteException {
        super();
    }

    public RMIMessage add(RMIMessage rmim) {
        //Retrieve parameters
        int a=((Integer)rmim.getParameter(0)).intValue();
        int b=((Integer)rmim.getParameter(1)).intValue();
        String r=new Integer(a+b).toString(); 
        //Set the result
        rmim.setResult(0, r);
        return rmim;
    }
}
